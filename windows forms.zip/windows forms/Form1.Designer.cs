﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Nome = new System.Windows.Forms.Label();
            this.text_Nome = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txt_CPF = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.txt_Telefone = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.txt_Email = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.txt_Endereco = new System.Windows.Forms.Label();
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.btn_Fechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_Nome
            // 
            this.txt_Nome.BackColor = System.Drawing.Color.LightBlue;
            this.txt_Nome.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Nome.Font = new System.Drawing.Font("Amiri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nome.Location = new System.Drawing.Point(10, 30);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(88, 51);
            this.txt_Nome.TabIndex = 0;
            this.txt_Nome.Text = "Nome:";
            this.txt_Nome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txt_Nome.Click += new System.EventHandler(this.label1_Click);
            // 
            // text_Nome
            // 
            this.text_Nome.Location = new System.Drawing.Point(144, 48);
            this.text_Nome.Name = "text_Nome";
            this.text_Nome.Size = new System.Drawing.Size(89, 22);
            this.text_Nome.TabIndex = 1;
            this.text_Nome.TextChanged += new System.EventHandler(this.text_Nome_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(144, 111);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(89, 22);
            this.textBox2.TabIndex = 3;
            // 
            // txt_CPF
            // 
            this.txt_CPF.BackColor = System.Drawing.Color.LightBlue;
            this.txt_CPF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_CPF.Font = new System.Drawing.Font("Amiri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CPF.Location = new System.Drawing.Point(12, 92);
            this.txt_CPF.Name = "txt_CPF";
            this.txt_CPF.Size = new System.Drawing.Size(65, 52);
            this.txt_CPF.TabIndex = 2;
            this.txt_CPF.Text = "CPF:";
            this.txt_CPF.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(144, 178);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(89, 22);
            this.textBox3.TabIndex = 5;
            // 
            // txt_Telefone
            // 
            this.txt_Telefone.BackColor = System.Drawing.Color.LightBlue;
            this.txt_Telefone.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Telefone.Font = new System.Drawing.Font("Amiri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Telefone.Location = new System.Drawing.Point(12, 161);
            this.txt_Telefone.Name = "txt_Telefone";
            this.txt_Telefone.Size = new System.Drawing.Size(99, 49);
            this.txt_Telefone.TabIndex = 4;
            this.txt_Telefone.Text = "Telefone:";
            this.txt_Telefone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(144, 240);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(89, 22);
            this.textBox4.TabIndex = 7;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // txt_Email
            // 
            this.txt_Email.BackColor = System.Drawing.Color.LightBlue;
            this.txt_Email.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Email.Font = new System.Drawing.Font("Amiri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Email.Location = new System.Drawing.Point(12, 223);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(84, 49);
            this.txt_Email.TabIndex = 6;
            this.txt_Email.Text = "Email:";
            this.txt_Email.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(144, 304);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(89, 22);
            this.textBox5.TabIndex = 9;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // txt_Endereco
            // 
            this.txt_Endereco.BackColor = System.Drawing.Color.LightBlue;
            this.txt_Endereco.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Endereco.Font = new System.Drawing.Font("Amiri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Endereco.Location = new System.Drawing.Point(12, 285);
            this.txt_Endereco.Name = "txt_Endereco";
            this.txt_Endereco.Size = new System.Drawing.Size(106, 52);
            this.txt_Endereco.TabIndex = 8;
            this.txt_Endereco.Text = "Endereço:";
            this.txt_Endereco.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txt_Endereco.Click += new System.EventHandler(this.label5_Click);
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Salvar.Location = new System.Drawing.Point(23, 364);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(88, 23);
            this.btn_Salvar.TabIndex = 10;
            this.btn_Salvar.Text = "&Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = false;
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // btn_Fechar
            // 
            this.btn_Fechar.BackColor = System.Drawing.Color.White;
            this.btn_Fechar.Location = new System.Drawing.Point(144, 364);
            this.btn_Fechar.Name = "btn_Fechar";
            this.btn_Fechar.Size = new System.Drawing.Size(102, 23);
            this.btn_Fechar.TabIndex = 11;
            this.btn_Fechar.Text = "Fechar";
            this.btn_Fechar.UseVisualStyleBackColor = false;
            this.btn_Fechar.Click += new System.EventHandler(this.btn_Fechar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1303, 605);
            this.Controls.Add(this.btn_Fechar);
            this.Controls.Add(this.btn_Salvar);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.txt_Endereco);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.txt_Email);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.txt_Telefone);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.txt_CPF);
            this.Controls.Add(this.text_Nome);
            this.Controls.Add(this.txt_Nome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txt_Nome;
        private System.Windows.Forms.TextBox text_Nome;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label txt_Endereco;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label txt_CPF;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label txt_Telefone;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label txt_Email;
        private System.Windows.Forms.Button btn_Salvar;
        private System.Windows.Forms.Button btn_Fechar;
    }
}

